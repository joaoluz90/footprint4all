package pt.iade.footprint4all;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Footprint4allApplication {

	public static void main(String[] args) {
		SpringApplication.run(Footprint4allApplication.class, args);
	}

}
