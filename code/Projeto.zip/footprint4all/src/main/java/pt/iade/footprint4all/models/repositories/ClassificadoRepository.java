package pt.iade.footprint4all.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.footprint4all.models.Classificado;

public interface ClassificadoRepository extends CrudRepository<Classificado, Integer> {
}
