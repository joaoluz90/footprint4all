package pt.iade.footprint4all.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.footprint4all.models.Administrador;

public interface AdministradorRepository extends CrudRepository<Administrador, Integer> {
}
