package pt.iade.footprint4all.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.footprint4all.models.Utilizador;

public interface UtilizadorRepository extends CrudRepository<Utilizador, Integer> {
}
