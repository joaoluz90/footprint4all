package pt.iade.footprint4all.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.footprint4all.models.Escala;

public interface EscalaRepository extends CrudRepository<Escala, Integer> {

}
    