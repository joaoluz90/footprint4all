package pt.iade.footprint4all;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Footprint4allApplicationTests {

	@Test
	void contextLoads() {
	}

}
